---
name: Feature Request
about: Request a feature for lualine
title: "Feat: "
labels: new feature
---

<!--
  Before creating a new request: search existing issues and prs
  and ensure it hasn't been already requested.
-->

### Requested feature

<!-- Describe the feature with details. -->

### Motivation

<!-- Explain why you think it should be included in lualine.-->
